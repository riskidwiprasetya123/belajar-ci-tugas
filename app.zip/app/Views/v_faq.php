<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
ini halaman F.A.Q
<?= $this->endSection() ?>